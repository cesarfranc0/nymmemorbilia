package com.ecommerce.nymmemorabilia;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NymmemorabiliaApplication {

	public static void main(String[] args) {
		SpringApplication.run(NymmemorabiliaApplication.class, args);
	}

}
