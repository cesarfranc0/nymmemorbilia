package com.ecommerce.nymmemorabilia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NymmemorabiliaApplicationTests {

	@Test
	void contextLoads() {
	}

}
